var baseUrl = 'https://stb.aeplcdn.com/bikewale/';
var baseWBUrl = 'https://stb.aeplcdn.com/bikewale/';
var APPSHELL = baseUrl + 'UI/pwa/appshell-1f8d629b5f.html';

importScripts("https://stb.aeplcdn.com/bikewale/min/ui/src/firebase-notification-custom-tracking-f7729d91fb.js");
importScripts('https://storage.googleapis.com/workbox-cdn/releases/4.3.1/workbox-sw.js');
importScripts('https://www.gstatic.com/firebasejs/8.4.3/firebase-app.js');
importScripts('https://www.gstatic.com/firebasejs/8.4.3/firebase-messaging.js');

workbox.setConfig({debug: false}); // comment it to enable workbox logging

// firebase setup
firebase.initializeApp({
  "apiKey": "AIzaSyAGqwrEVdEKwmFME_KdvALF1i9_0bH7eCo",
  "authDomain": "bikewale-android.firebaseapp.com",
  "databaseURL": "https://bikewale-android.firebaseio.com",
  "projectId": "bikewale-android",
  "storageBucket": "bikewale-android.appspot.com",
  "messagingSenderId": "1018464172822",
  "appId": "1:1018464172822:web:c7d20788ed7d10009c2e37"
});
var messaging = firebase.messaging();

// push notification defaults
var defaultIcon = 'https://imgd.aeplcdn.com/0x0/bw/static/icons/logo/bikewale-app-192x192.png';
var defaultTitle = 'BikeWale';
var defaultBadge = 'https://imgd.aeplcdn.com/0x0/bw/static/icons/logo/bikewale-app-73x71.png';

workbox.core.skipWaiting(); // https://github.com/GoogleChrome/workbox/blob/master/packages/workbox-core/src/skipWaiting.ts
workbox.core.clientsClaim(); // https://github.com/GoogleChrome/workbox/blob/master/packages/workbox-core/src/clientsClaim.ts
workbox.precaching.cleanupOutdatedCaches(); // Adds an `activate` event listener which will clean up incompatible precaches that were created by older versions of Workbox.
workbox.precaching.precacheAndRoute([
  "https://stb.aeplcdn.com/bikewale/UI/pwa/appshell-1f8d629b5f.html"
]);

var PRECACHE_NAME = workbox.core.cacheNames.precache; // https://developers.google.com/web/tools/workbox/guides/configure-workbox#configure_cache_names

function fetchRequest(url) {
    return fetch(url).then(function (response) {
        if (!response.ok) {
            throw new TypeError('bad response status');
        }
        return response;
    }).catch(function(err){})
}

workbox.routing.registerRoute(/.*\/news\/auto-expo-2020\/.*?/, new workbox.strategies.NetworkOnly(), 'GET');
workbox.routing.registerRoute(/.*\/(hindi\/)?(news|expert-reviews)\/.*\/amp\/?/, new workbox.strategies.NetworkOnly(), 'GET');
workbox.routing.registerRoute(/.*\/api\/v.\/pwa\/cms\/id\/[0-9]+\/page\/.*/, new workbox.strategies.NetworkOnly(), 'GET'); // News Details
workbox.routing.registerRoute(/.*\/api\/v.\/pwa\/cms\/id\/[0-9]+\/pages\/.*/, new workbox.strategies.NetworkOnly(), 'GET'); // Expert Reviews Details


const detectMob = () => {
  const toMatch = [
      /Android/i,
      /webOS/i,
      /iPhone/i,
      /iPad/i,
      /iPod/i,
      /BlackBerry/i,
      /Windows Phone/i
  ];

  return toMatch.some((toMatchItem) => {
      return navigator.userAgent.match(toMatchItem);
  });
}

const fetchAppShell = input => {
  if (input.event.request.method === 'GET' && input.event.request.headers.get('accept').includes('text/html')) {
      return caches.match(APPSHELL).then(function (response) {
          if (response) {
              return response;
          }
          else {
              caches.open(PRECACHE_NAME).then(function (cache) {
                  fetch(APPSHELL).then(function (response) {
                      if(response)
                          cache.put(APPSHELL, response);
                  })
              })
              return fetchRequest(input.url.href);
          }
      }).catch(function (error) {
          fetchRequest(input.url.href);
      })
  }
  else {
      fetchRequest(input.url.href);
  }
}

workbox.routing.registerRoute(/.*\/api\/(v.\/)?pwa\/.*/, new workbox.strategies.StaleWhileRevalidate()); // Stale While Revalidate for API response

self.addEventListener('push', function (event) {
    if (event.data) {
        var notificationData = event.data.json();
        var options = {
            body: notificationData.data.description,
            tag: btoa(notificationData.data.detailUrl),
            icon: notificationData.data.smallPicUrl ? getImageUrl(notificationData.data.smallPicUrl).replace("http:", "https:") : "",
            image: notificationData.data.largePicUrl ? getImageUrl(notificationData.data.largePicUrl).replace("http:", "https:") : "",
            vibrate: [300, 100, 400], // Vibrate 300ms, pause 100ms, then vibrate 400ms
            data: notificationData.data,
            badge: defaultBadge,
            actions: [
                {
                    action: 'readMore',
                    title: 'Read More'
                }]
        };
    }

    event.waitUntil(
    self.registration.showNotification(notificationData.data.title ? notificationData.data.title : defaultTitle, options).then(function (event) {
        fetch(customTracking.getTrackingUrl("BW_WebNotification", "NotificationImpression", customTracking.getEventLabel(notificationData.data.title, notificationData.data.alertId, notificationData.data.alertTypeId)),
        {
            credentials: 'same-origin'
        })
    })
    );
});

function getImageUrl(imageUrl) {
    return imageUrl + ((imageUrl.indexOf("?") > -1) ? "&" : "?") + "q=75";
}

self.addEventListener('notificationclick', function (event) {
    event.notification.close();
    var notificationData = event.notification.data;
    var requestURL = notificationData.detailUrl.replace("http:", "https:");
    
    // for news details page : API handling
    if (requestURL.indexOf('api/cms') != -1) {
        if (requestURL[requestURL.length - 1] != '/') {
            requestURL += '/';
        }
        fetch(customTracking.getTrackingUrl("BW_WebNotification", "NotificationClick", customTracking.getEventLabel(notificationData.title, notificationData.alertId, notificationData.alertTypeId)), { credentials: 'same-origin' });
        event.waitUntil(
        fetch(requestURL, { credentials: 'same-origin' })
        .then(function (response) {
            return response.json();
        })
        .then(function (myJson) {
            var completeUrl = myJson.ShareUrl + '?utm_source=BWSubscription&utm_medium=BrowserNotification&utm_campaign=BikewaleWebNotification&utm_term=' + notificationData.alertId;
            return clients.openWindow(completeUrl);
        })
        );
    }
    else {
        // rest : open detailUrl directly
        let completeRequestURL = notificationData.isTargeted !== "false" ? requestURL : requestURL + '?utm_source=BWSubscription&utm_medium=BrowserNotification&utm_campaign=BikewaleWebNotification&utm_term=' + notificationData.alertId;

        fetch(customTracking.getTrackingUrl("BW_WebNotification", "NotificationClick", customTracking.getEventLabel(notificationData.title, notificationData.alertId, notificationData.alertTypeId)), { credentials: 'same-origin' });
        event.waitUntil(
            clients.openWindow(completeRequestURL)
        );
    }

});


self.addEventListener('notificationclose', function (event) {
    var notificationData = event.notification.data;
    event.waitUntil(
        fetch(customTracking.getTrackingUrl("BW_WebNotification", "NotificationClose", customTracking.getEventLabel(notificationData.title, notificationData.alertId, notificationData.alertTypeId)),
        {
            credentials: 'same-origin'
        })
        );

});

// Push Notification Subscription handling for AMP pages

/** @enum {string} */
const WorkerMessengerCommand = {
    /*
      Used to request the current subscription state.
     */
    AMP_SUBSCRIPTION_STATE: 'amp-web-push-subscription-state',
    /*
      Used to request the service worker to subscribe the user to push.
      Notification permissions are already granted at this point.
     */
    AMP_SUBSCRIBE: 'amp-web-push-subscribe',
    /*
      Used to unsusbcribe the user from push.
     */
    AMP_UNSUBSCRIBE: 'amp-web-push-unsubscribe',
};

self.addEventListener('message', event => {
    /*
      Messages sent from amp-web-push have the format:
      - command: A string describing the message topic (e.g.
        'amp-web-push-subscribe')
      - payload: An optional JavaScript object containing extra data relevant to
        the command.
     */
    const {command} = event.data;
  
    switch (command) {
      case WorkerMessengerCommand.AMP_SUBSCRIPTION_STATE:
        onMessageReceivedSubscriptionState();
        break;
      case WorkerMessengerCommand.AMP_SUBSCRIBE:
        onMessageReceivedSubscribe();
        break;
      case WorkerMessengerCommand.AMP_UNSUBSCRIBE:
        onMessageReceivedUnsubscribe();
        break;
    }
  });

/**
  Broadcasts a single boolean describing whether the user is subscribed.
 */
function onMessageReceivedSubscriptionState() {
    let retrievedPushSubscription = null;
    self.registration.pushManager
      .getSubscription()
      .then(pushSubscription => {
        retrievedPushSubscription = pushSubscription;
        if (!pushSubscription) {
          return null;
        } else {
          return self.registration.pushManager.permissionState(
            pushSubscription.options
          );
        }
      })
      .then(permissionStateOrNull => {
        if (permissionStateOrNull == null) {
          broadcastReply(WorkerMessengerCommand.AMP_SUBSCRIPTION_STATE, false);
        } else {
          const isSubscribed =
            !!retrievedPushSubscription && permissionStateOrNull === 'granted';
          broadcastReply(
            WorkerMessengerCommand.AMP_SUBSCRIPTION_STATE,
            isSubscribed
          );
        }
      });
  }
  
  /**
    Subscribes the visitor to push.
    The broadcast value is null (not used in the AMP page).
   */
  function onMessageReceivedSubscribe() {
    
    messaging.getToken().then( token =>{
        let cookie = '';
        let topics = [6];   // modify if it supports desktop subscription
        let platformId = 2;
        let data = JSON.stringify({
            "bwCookie" : cookie,
            "fcmToken": token,
            "topics": topics,
            "platformId": platformId
        });
        if(token){
            saveFCMDataToServer(data, true);
        }
        fetch(customTracking.getTrackingUrl("BWEditorial_Details_Page", "UserSubscribedViaTopOrBottomSubscribeButton_AMP", "token="+token),
        {
            credentials: 'same-origin'
        })
        broadcastReply(WorkerMessengerCommand.AMP_SUBSCRIBE, null);
    })
  }
  
  /**
    Unsubscribes the subscriber from push.
    The broadcast value is null (not used in the AMP page).
   */
  function onMessageReceivedUnsubscribe() {
    self.registration.pushManager
      .getSubscription()
      .then(subscription => subscription.unsubscribe())
      .then(() => {
        // OPTIONALLY IMPLEMENT: Forward the unsubscription to your server here
        broadcastReply(WorkerMessengerCommand.AMP_UNSUBSCRIBE, null);
      });
  }

/**
 * Sends a postMessage() to all window frames the service worker controls.
 * @param {string} command
 * @param {!JsonObject} payload
 */
function broadcastReply(command, payload) {
    self.clients.matchAll().then(clients => {
      for (let i = 0; i < clients.length; i++) {
        const client = clients[i];
        client./*OK*/ postMessage({
          command,
          payload,
        });
      }
    });
}

function saveFCMDataToServer(data, subscribe) {
    fetch('/api/WebNotification/', {
        method: 'POST',
        credentials: 'same-origin',
        headers: {
            'Content-Type': 'application/json'
        },
        body: data
    }).then(function(){
        // add tracking here
    }).catch(function(){
        // add tracking here
    });
}
